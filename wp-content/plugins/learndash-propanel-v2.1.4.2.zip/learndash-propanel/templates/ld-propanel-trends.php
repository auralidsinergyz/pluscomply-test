<?php
/**
 * Learndash ProPanel Trends
 *
 * Shows trends
 */
?>

<div class="canvas-wrap">
	<canvas id="proPanelTrends" width="400" height="250"></canvas>
</div>