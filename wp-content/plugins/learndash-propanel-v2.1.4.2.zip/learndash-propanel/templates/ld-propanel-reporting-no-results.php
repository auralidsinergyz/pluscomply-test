<?php
/**
 * Learndash ProPanel Widget Loading
 */
?>
<tr>
	<td colspan="<?php echo count( $this->filter_headers ); ?>"><strong class="note please-choose-filter"><?php esc_html_e( 'No Results Found.', 'ld_propanel' ); ?></td>
</tr>
