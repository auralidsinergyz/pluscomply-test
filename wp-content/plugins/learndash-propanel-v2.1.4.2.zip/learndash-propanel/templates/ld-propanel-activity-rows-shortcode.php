<?php
/**
 * Learndash ProPanel Activity Rows Shortcode Template
 */
?>
<?php 
/* 
This template is a stub and calls the main template 'learndash-propanel-activity-rows.php' to display yhe output. 

If you want to customize this template output can can copy it to your theme directory and add the needed code for output
*/

include ld_propanel_get_template( 'ld-propanel-activity-rows.php' );