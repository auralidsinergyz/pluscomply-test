<?php
/**
 * LearnDash Settings Page Custom Labels.
 *
 * @since 2.4.0
 * @deprecated 3.6.0
 * @package LearnDash\Settings\Pages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

_deprecated_file( basename( __FILE__ ), '3.6.0' );
