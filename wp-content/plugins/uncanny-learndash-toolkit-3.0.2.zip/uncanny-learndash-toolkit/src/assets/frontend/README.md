##  `npm start`
- Use to compile and run in development mode.
- Watches for any changes and reports back any errors in your code.

##  `npm run build`
- Use to build production code inside `dist` folder.
- Watches for any changes and reports back any errors in your code.