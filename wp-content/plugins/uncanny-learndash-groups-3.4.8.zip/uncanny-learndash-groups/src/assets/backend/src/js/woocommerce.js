jQuery(document).ready(function () {
	var selectedProductType = '';
  var $group_pricing = '#general_product_data, .options_group.pricing'
	jQuery($group_pricing).addClass('show_if_courses').addClass('show_if_license').addClass('show_if_group').show();
	jQuery('li.advanced_options').addClass('show_if_courses').addClass('show_if_license').removeClass('active');
	//jQuery('li.general_options').addClass('show_if_courses').addClass('show_if_license').addClass('show_if_subscription').addClass('active').show();
	jQuery('#advanced_product_data').hide();

	jQuery('#product-type').change(function () {
		//console.log(jQuery(this).val());
		selectedProductType = jQuery(this).val();
	});

	if ('courses' === selectedProductType) {
		jQuery('li.general_options').addClass('show_if_courses').show();
		//jQuery('li.inventory_options').addClass('show_if_courses').show();
		jQuery('#advanced_product_data').hide();
		jQuery('.advanced_options').removeClass('active');
		jQuery('#general_product_data').hide();
		jQuery($group_pricing).removeClass('active').hide();
	}

	if ('group' === selectedProductType) {
		jQuery('li.general_options').addClass('show_if_group').show();
		//jQuery('li.inventory_options').addClass('show_if_courses').show();
		jQuery('#advanced_product_data').hide();
		jQuery('.advanced_options').removeClass('active');
		jQuery('#general_product_data').hide();
		jQuery($group_pricing).removeClass('active').hide();
	}

	//selectedProductType = jQuery('#product-type').val();
	if ('license' === selectedProductType) {
		jQuery('li.general_options').addClass('show_if_license').show();
		jQuery('#advanced_product_data').hide();
		jQuery('.advanced_options').removeClass('active');
		jQuery('#general_product_data').hide();
		jQuery($group_pricing).removeClass('hidden').show();
		jQuery('.license_options').addClass('active').show();
		jQuery('#license_options').show();
	}
});