<?php

namespace uncanny_learndash_groups;
if ( isset( $_GET['registered'] ) ) { ?>
	<div class="registered">
		<h2><?php __( 'Congratulations! You have successfully redeemed your key.', 'uncanny-learndash-groups' ); ?></h2>
	</div>
	<?php
} elseif ( is_user_logged_in() ) { ?>
	<form id="ulgm_registration_form" class="uncanny-learndash-groups" action="" method="POST">
		<fieldset>
			<table class="table table-form form-table clr">
				<tr>
					<td class="label"><label
								for="code_registration"><?php esc_html_e( 'Enrollment Key', 'uncanny-learndash-groups' ); ?></label>
					</td>
					<td class="input"><input name="ulgm_code_redeem"
					                         id="ulgm_code_redeem"
					                         required="required"
					                         class="required"
					                         value="<?php if ( isset( $_POST['ulgm_code_redeem'] ) ) {
						                         echo $_POST['ulgm_code_redeem'];
					                         } ?>"
					                         placeholder="<?php esc_html_e( 'Enrollment Key', 'uncanny-learndash-groups' ); ?>"
					                         type="text"/></td>
				</tr>
				<tr>
					<td class="label"></td>
					<td class="input"><input type="submit" class="btn btn-default"
					                         value="<?php esc_html_e( 'Redeem Code', 'uncanny-learndash-groups' ); ?>"/>
						<input type="hidden" name="_ulgm_code_nonce"
						       value="<?php echo wp_create_nonce( Utilities::get_prefix() ); ?>"/>
						<input type="hidden" name="key"
						       value="<?php echo crypt( get_the_ID(), 'uncanny-learndash-groups' ); ?>"/>
					</td>
				</tr>
			</table>
		</fieldset>
	</form>
	<?php
} else {
	echo '<h3>' . __( 'Sorry, please log in to redeem code.', 'uncanny-learndash-groups' ) . '</h3>';
} ?>