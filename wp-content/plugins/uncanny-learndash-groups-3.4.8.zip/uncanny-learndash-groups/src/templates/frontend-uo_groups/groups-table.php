<?php

namespace uncanny_learndash_groups;

?>

		<!-- Table -->
		<div class="uo-row uo-groups-table">
			<div class="uo-table uo-jplist">
				<div class="uo-group-management-table uo-pseudo-table leaders">
					<!-- Header -->
					<div class="uo-row uo-table-row uo-table-header">
						<header class="jplist-panel pseudo-table-header">
							<div class="uo-row" data-control-type="sort-buttons-group" data-control-name="header-sort-buttons" data-control-action="sort" data-mode="single" data-datetime-format="{month}/{day}/{year}">
								<?php

								$cell = array(
									'select-all' => array(
										'css-classes' => 'header-leaders-select-all',
										'cell-width'  => '0_5',
									),
									'first-name' => array(
										'css-classes' => 'header-leaders-first-name',
										'cell-width'  => '2',
									),
									'last-name'  => array(
										'css-classes' => 'header-leaders-last-name',
										'cell-width'  => '2',
									),
									'email' 	 => array(
										'css-classes' => 'header-leaders-email',
										'cell-width'  => '5_5',
									),
								);

								$css_classes = $cell['select-all']['css-classes'];
								$cell_width = $cell['select-all']['cell-width'];

								?>

								<div class="header-column <?php echo $css_classes; ?> uo-table-cell uo-table-cell-<?php echo $cell_width; ?>">
									<label class="uo-checkbox">
										<input class="uo-checkbox-input" name="select-all-group-leaders" id="select-all-group-leaders" type="checkbox">
										<span class="uo-checkbox-checkmark"></span>
									</label>
								</div>

								<?php 

								foreach (GroupManagementInterface::$ulgm_management_shortcode['table']['group_leaders']['headers'] as $header){

									$css_classes = $cell[$header['slug']]['css-classes'];
									$cell_width = $cell[$header['slug']]['cell-width'];

									?>

									<div class="header-column <?php echo $css_classes; ?> uo-table-cell uo-table-cell-<?php echo $cell_width; ?>">
										<span class="uog_header header"><?php echo $header['title']; ?></span>
									</div>

								<?php } ?>
							</div>
						</header>
					</div>
				</div>

				
				<!-- Content & No results -->
				<div class="uo-row uo-table-content">
					<div class="pseudo-table-body">
							<?php

							$cell = array(
								'select' => array(
									'css-classes' => 'content-leaders-select',
									'cell-width'  => '0_5',
									'clipboard'	  => false
								),
								'first-name' => array(
									'css-classes' => 'content-leaders-first-name',
									'cell-width'  => '2',
									'clipboard'	  => false
								),
								'last-name'  => array(
									'css-classes' => 'content-leaders-last-name',
									'cell-width'  => '2',
									'clipboard'	  => false
								),
								'email' 	 => array(
									'css-classes' => 'content-leaders-email',
									'cell-width'  => '5_5',
									'clipboard'	  => false
								),
							);

							foreach (GroupManagementInterface::$ulgm_group_leaders_data as $group_leader_id => $ulgm_group_leaders_data_set){

								?>
								<div class="uo-row uo-jplist-row uo-table-content uo-tbl-item body-row">

									<?php

									$css_classes = $cell['select']['css-classes'];
									$cell_width = $cell['select']['cell-width'];

									?>

									<div class="<?php echo $css_classes; ?> uo-table-cell uo-table-cell-<?php echo $cell_width; ?>">
										<?php
											if ($group_leader_id === get_current_user_id()){}
											else { ?>
												<label class="uo-checkbox">
													<input class="uo-checkbox-input select-group-leader" name="group-leader-id[]" value="<?php echo $group_leader_id; ?>" type="checkbox">
													<span class="uo-checkbox-checkmark"></span>
												</label>
											<?php }
										?>
									</div>

									<?php
									foreach ($ulgm_group_leaders_data_set as $column => $ulgm_group_leader_data){
										$slug = GroupManagementInterface::$ulgm_management_shortcode['table']['group_leaders']['headers'][ $column ]['slug'];

										$css_classes = $cell[$slug]['css-classes'];
										$cell_width = $cell[$slug]['cell-width'];
										$copy_to_clipboard = $cell[$slug]['clipboard'];

										?>
										<div class="<?php echo $css_classes; ?> uo-table-cell uo-table-cell-<?php echo $cell_width; ?>">
											<span data-header="<?php echo GroupManagementInterface::$ulgm_management_shortcode['table']['group_leaders']['headers'][ $column ]['title']; ?>" class="header-column-inline"></span>

											<span class="<?php echo $slug; ?>"><?php echo $ulgm_group_leader_data; ?></span>

										</div>
										<?php
									}
									?>
								</div>
								<?php
							}
							?>
					</div>
				</div>



			</div>
		</div>

	</div>
</section>