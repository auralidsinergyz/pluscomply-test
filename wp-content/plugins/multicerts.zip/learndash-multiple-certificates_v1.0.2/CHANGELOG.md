## 1.0.2
-  UI bug fixes
-  Buddyboss theme fixes
## 1.0.1
- Updated LearnDash certificate filters and hooks to newest LD version
- Fixed License issue
## 1.0.0
- Initial release