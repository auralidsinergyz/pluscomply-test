<?php
/**
 * Plugin Name: LearnDash Multi Certificates
 * Plugin URI: https://wooninjas.com/downloads/learndash-multi-certificates
 * Description: This add-on allows admin to provide multiple optional certificates to the student that they should select specific one for downloading.
 * Version: 1.0.2
 * Requires at least: 5.1
 * Requires PHP: 7.2
 * Author: WooNinjas
 * Author URI: https://wooninjas.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: LD-MC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PSR-4 Composer Autoloader
 */
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

if( ! function_exists('get_plugin_data') ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data        = get_plugin_data( __FILE__ );
$wp_upload_dir      = wp_get_upload_dir();


/* Define constants. */

// ! defined( 'LD_MC_NAME' )                      && define( 'LD_MC_NAME', $plugin_data['Name'] );
// ! defined( 'LD_MC_VERSION' )                   && define( 'LD_MC_VERSION', $plugin_data['Version'] );
// ! defined( 'LD_MC_BASE' )                      && define( 'LD_MC_BASE', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );
// ! defined( 'LD_MC_TEXT_DOMAIN' )               && define( 'LD_MC_TEXT_DOMAIN', 'LD-MC' );
// // ! defined( 'LD_MC_ASSETS_SUFFIX' )             && define( 'LD_MC_ASSETS_SUFFIX', ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG === true ? '' : '.min' ) );
// ! defined( 'LD_MC_FILE' )                      && define( 'LD_MC_FILE', __FILE__ );
// ! defined( 'LD_MC_URL' )                       && define( 'LD_MC_URL', plugins_url( '', LD_MC_FILE ) );
// ! defined( 'LD_MC_URL_ASSETS' )                && define( 'LD_MC_URL_ASSETS', LD_MC_URL . '/assets' );
// ! defined( 'LD_MC_URL_ASSETS_CSS' )            && define( 'LD_MC_URL_ASSETS_CSS', LD_MC_URL_ASSETS . '/css' );
// ! defined( 'LD_MC_URL_ASSETS_JS' )             && define( 'LD_MC_URL_ASSETS_JS', LD_MC_URL_ASSETS . '/js' );
// ! defined( 'LD_MC_URL_ASSETS_IMAGES' )         && define( 'LD_MC_URL_ASSETS_IMAGES', LD_MC_URL_ASSETS . '/images' );
// ! defined( 'LD_MC_PATH' )                      && define( 'LD_MC_PATH', dirname( LD_MC_FILE ) );
// ! defined( 'LD_MC_PATH_ASSETS' )               && define( 'LD_MC_PATH_ASSETS', LD_MC_PATH . '/assets' );
// ! defined( 'LD_MC_PATH_ASSETS_IMAGES' )        && define( 'LD_MC_PATH_ASSETS_IMAGES', LD_MC_PATH_ASSETS . '/images' );
// ! defined( 'LD_MC_PATH_INCLUDES' )             && define( 'LD_MC_PATH_INCLUDES', LD_MC_PATH . '/includes' );
// ! defined( 'LD_MC_PATH_TEMPLATES' )            && define( 'LD_MC_PATH_TEMPLATES', LD_MC_PATH . '/templates' );
// ! defined( 'LD_MC_WP_UPLOAD_DIR' )             && define( 'LD_MC_WP_UPLOAD_DIR', $wp_upload_dir['basedir'] );
// ! defined( 'LD_MC_PATH_CERTIFICATES' )         && define( 'LD_MC_PATH_CERTIFICATES', LD_MC_WP_UPLOAD_DIR . '/learndash-multiple-certificates' );



/**
 * Plugin Directories Paths
 */
$plugins = get_plugins();
$learndash_dir_path = '';
$learndash_plugin_basename = '';
$ldcvss_plugin_basename = '';
foreach( $plugins as $plugin_main_file_path =>  $plugin ){
    if( $plugin['Name'] == 'LearnDash LMS' ){
        $learndash_plugin_basename = $plugin_main_file_path;
		$plugin_dir_path = $plugin_main_file_path;
		$plugin_dir_path_arr = preg_split("/\//", $plugin_dir_path);
		$learndash_dir_path = $plugin_dir_path_arr[0];
    }
    if( $plugin['Name'] == $plugin_data['Name'] ){
        $ldcvss_plugin_basename =  $plugin_main_file_path;
    }
}
/*
Start - Plugin Global Constants */
! defined( 'LD_MC_NAME' )                           && define( 'LD_MC_NAME', $plugin_data['Name'] );
! defined( 'LD_MC_VERSION' )                        && define( 'LD_MC_VERSION', $plugin_data['Version'] );
! defined( 'LD_MC_AUTHOR_NAME' )                    && define( 'LD_MC_AUTHOR_NAME', $plugin_data['AuthorName'] );
! defined( 'LD_MC_AUTHOR_SITE' )                    && define( 'LD_MC_AUTHOR_SITE', 'https:wooninjas.com' ); // $plugin_data['AuthorURI']  // edd.localhost.com
! defined( 'LD_MC_TEXT_DOMAIN' )                    && define( 'LD_MC_TEXT_DOMAIN', 'LD-MC' );
! defined( 'LD_MC_LD_NAME' )                        && define( 'LD_MC_LD_NAME', 'LearnDash LMS' );
! defined( 'LD_MC_LD_DIR_PATH' )                    && define( 'LD_MC_LD_DIR_PATH', $learndash_dir_path );
! defined( 'LD_MC_LD_MAIN_FILE_RELATIVE_PATH' )     && define( 'LD_MC_LD_MAIN_FILE_RELATIVE_PATH', $learndash_plugin_basename );
! defined( 'LD_MC_LD_MAIN_FILE_ABSOLUTE_PATH' )     && define( 'LD_MC_LD_MAIN_FILE_ABSOLUTE_PATH', WP_PLUGIN_DIR.'/'.LD_MC_LD_MAIN_FILE_RELATIVE_PATH );
! defined( 'LD_MC_MAIN_FILE_RELATIVE_PATH' )        && define( 'LD_MC_MAIN_FILE_RELATIVE_PATH', $ldcvss_plugin_basename);
! defined( 'LD_MC_MAIN_FILE_ABSOLUTE_PATH' )        && define( 'LD_MC_MAIN_FILE_ABSOLUTE_PATH', WP_PLUGIN_DIR.'/'.LD_MC_MAIN_FILE_RELATIVE_PATH );
! defined( 'LD_MC_BASE_DIR' )                       && define( 'LD_MC_BASE_DIR', plugin_basename( LD_MC_MAIN_FILE_ABSOLUTE_PATH ) );
! defined( 'LD_MC_DIR_PATH' )                       && define( 'LD_MC_DIR_PATH', plugin_dir_path( LD_MC_MAIN_FILE_ABSOLUTE_PATH ) );
! defined( 'LD_MC_ASSETS_DIR_PATH' )                && define( 'LD_MC_ASSETS_DIR_PATH', trailingslashit( LD_MC_DIR_PATH . 'assets' ) );
! defined( 'LD_MC_WP_UPLOAD_DIR' )                  && define( 'LD_MC_WP_UPLOAD_DIR', $wp_upload_dir['basedir'] );
! defined( 'LD_MC_PATH_CERTIFICATES' )              && define( 'LD_MC_PATH_CERTIFICATES', LD_MC_WP_UPLOAD_DIR . '/ld-mc-certificates' );


! defined( 'LD_MC_DIR_URL' )            && define( 'LD_MC_DIR_URL', trailingslashit( plugin_dir_url( LD_MC_MAIN_FILE_ABSOLUTE_PATH ) ) );
! defined( 'LD_MC_ASSETS_URL' )         && define( 'LD_MC_ASSETS_URL', trailingslashit( LD_MC_DIR_URL . 'assets' ) );
! defined( 'LD_MC_WP_UPLOAD_URL' )      && define( 'LD_MC_WP_UPLOAD_URL', $wp_upload_dir['baseurl'] );
! defined( 'LD_MC_URL_CERTIFICATES' )   && define( 'LD_MC_URL_CERTIFICATES', LD_MC_WP_UPLOAD_URL . '/ld-mc-certificates' );

/**
 * Plugin URLS*
*/
//define( 'LD_MC_BASE_URL', get_bloginfo( 'url' ) );
//define( 'LD_MC_DIR_URL', trailingslashit( plugin_dir_url( LD_MC_MAIN_FILE_ABSOLUTE_PATH ) ) );
//define( 'LD_MC_ASSETS_URL', trailingslashit( LD_MC_DIR_URL . 'assets' ) );
/* End - Plugin Global Constants */


/**
 * App Bootstraping
 */
function learndash_multiple_certificates() {
	if( \LDMC\Bootstrap\Requirements::get_instance()->validate_requirements() ) {
        $LDCVSS = \LDMC\Bootstrap\App::get_instance();
        do_action('ld_mc_loaded');
    }
}
add_action( 'plugins_loaded', 'learndash_multiple_certificates' );