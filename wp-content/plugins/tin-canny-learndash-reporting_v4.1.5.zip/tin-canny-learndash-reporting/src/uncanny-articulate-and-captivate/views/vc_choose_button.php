<div id="vc-snc-choosen-file" class="vc_col-sm-12 vc_column">
	<div>Your selected file is <code></code>.</div>
	<a href="#" class="button change_file"><?php _e( 'Change File', 'uncanny-learndash-reporting' ); ?></a>
</div>
