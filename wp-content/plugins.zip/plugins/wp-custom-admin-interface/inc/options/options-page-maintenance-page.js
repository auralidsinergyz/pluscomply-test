jQuery(document).ready(function ($) {
    
    //initialise datepicker
    if($('.datepicker').length){    
        $('.datepicker').datepicker({  
        dateFormat:"yy-mm-dd",    
        });   
    } 

});