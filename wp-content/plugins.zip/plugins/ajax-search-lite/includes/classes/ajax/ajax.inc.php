<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASL_CLASSES_PATH . "ajax/class-asl-abstract.php");
require_once(ASL_CLASSES_PATH . "ajax/class-asl-maintenance.php");
require_once(ASL_CLASSES_PATH . "ajax/class-asl-search.php");