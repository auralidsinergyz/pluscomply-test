<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASL_CLASSES_PATH . "shortcodes/class-asl-abstract.php");
require_once(ASL_CLASSES_PATH . "shortcodes/class-asl-search.php");